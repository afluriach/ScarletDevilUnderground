print("init script")

App.setUnlockAllEquips(true)
