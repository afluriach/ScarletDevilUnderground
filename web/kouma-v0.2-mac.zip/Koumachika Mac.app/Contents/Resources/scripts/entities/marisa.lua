function init()
end

function update()
end

function onDetect(obj)
end

function onEndDetect(obj)
end
